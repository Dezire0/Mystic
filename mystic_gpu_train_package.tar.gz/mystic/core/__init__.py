"""Core orchestration package."""

